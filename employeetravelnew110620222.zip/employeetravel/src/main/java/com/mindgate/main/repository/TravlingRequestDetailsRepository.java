package com.mindgate.main.repository;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.pojo.TravellingRequestDetails;


@Repository
public class TravlingRequestDetailsRepository implements TravlingRequestDetailsRepositoryInterface{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private TravlingRequestDetailsRowMapper travlingRequestDetailsRowMapper;
	private int resultCount;
	
	//private static final String INSERT_TravellingRequestDetails = " INSERT INTO travelling_request_details(TRAVEL_REQUEST_ID,TRAVEL_DEPARTURE_DATE,TRAVEL_RETURN_DATE,TRAVEL_REASON ,TRAVEL_MODE ,TRAVEL_STATUS ,PROJECT_MANAGER_STATUS ,DIRECTOR_STATUS ,TRAVEL_LOCATION,EMPLOYEE_ID  )VALUES (seq_travelling_request_details.NEXTVAL,?,?,?,?,?,?,?,?,?)";
	private static final String SELECT_ALL_TravellingRequestDetails = "SELECT * FROM travelling_request_details";
	private static final String SELECT_SINGLE_TravellingRequestDetailsBytravelRequestId= "SELECT * FROM travelling_request_details WHERE TRAVEL_REQUEST_ID= ?";
	//private static final String UPDATE_travelTravellingRequestDetailsBytravelRequestId = "UPDATE travelling_request_details SET TRAVEL_DEPARTURE_DATE=?,TRAVEL_RETURN_DATE=?,TRAVEL_REASON=? ,TRAVEL_MODE=? ,TRAVEL_STATUS=? ,PROJECT_MANAGER_STATUS=? ,DIRECTOR_STATUS=? ,EMPLOYEE_ID=?,TRAVEL_LOCATION=? ,TRAVEL_DETAILS_ID=? , DOCUMENT_ID=?  WHERE TRAVEL_REQUEST_ID = ?";
//	private static final String DELETE_TravellingRequestDetailsBytravelRequestId= "DELETE travelling_request_details WHERE TRAVEL_REQUEST_ID= ? ";
	private static final String INSERT_TravellingRequestDetails = " INSERT INTO travelling_request_details(TRAVEL_REQUEST_ID,TRAVEL_DEPARTURE_DATE,TRAVEL_RETURN_DATE,TRAVEL_REASON ,TRAVEL_MODE ,TRAVEL_STATUS ,PROJECT_MANAGER_STATUS ,DIRECTOR_STATUS ,TRAVEL_LOCATION,EMPLOYEE_ID  )VALUES (seq_travelling_request_details.NEXTVAL,?,?,?,?,?,?,?,?,?)";
	private static final String SELECT_ALL_TravellingReqestsByEMPId = "SELECT * FROM travelling_request_details where EMPLOYEE_ID=?";
	private static final String UPDATE_travelTravellingRequestDetailsBytravelRequestId = "UPDATE travelling_request_details SET TRAVEL_STATUS=?   WHERE TRAVEL_REQUEST_ID = ?";
	private static final String UPDATE_Manager_Status = "UPDATE travelling_request_details SET PROJECT_MANAGER_STATUS=?   WHERE TRAVEL_REQUEST_ID = ?";
	private static final String UPDATE_Director_Status = "UPDATE travelling_request_details SET DIRECTOR_STATUS=?   WHERE TRAVEL_REQUEST_ID = ?";
	private static final String SELECT_ALL_TRAVELINGREQFORAGENT = "SELECT * FROM travelling_request_details where PROJECT_MANAGER_STATUS  ='APPROVED'";
	
	private static final String SELECT_ALL_TRAVELINGREQUESTBYMANAGERID = "SELECT *  FROM travelling_request_details where EMPLOYEE_ID in (select EMPLOYEE_ID from employee_details where MANAGER_ID =?)";
	
	
	private static final String SELECT_ALL_PENDING_TRAVELINGREQUEST_BY_MANAGERID  ="SELECT *  FROM travelling_request_details where EMPLOYEE_ID in (select EMPLOYEE_ID from employee_details where MANAGER_ID =?) AND PROJECT_MANAGER_STATUS = 'PENDING'";
	private static final String SELECT_ALL_ACCEPT_TRAVELINGREQUEST_BY_MANAGERID  ="SELECT *  FROM travelling_request_details where EMPLOYEE_ID in (select EMPLOYEE_ID from employee_details where MANAGER_ID =?) AND PROJECT_MANAGER_STATUS = 'APPROVED'";
	private static final String SELECT_ALL_REJECT_TRAVELINGREQUEST_BY_MANAGERID  ="SELECT *  FROM travelling_request_details where EMPLOYEE_ID in (select EMPLOYEE_ID from employee_details where MANAGER_ID =?) AND PROJECT_MANAGER_STATUS = 'REJECTED'";
	private static final String SELECT_ALL_TRVALING_REQUEST_FOR_DIRECTOR = "SELECT * FROM travelling_request_details WHERE TRAVEL_STATUS='REJECTED'";
	private static final String SELECT_ALL_ACCEPTED_TRVALING_REQUEST_FOR_AGENT = "SELECT * FROM travelling_request_details WHERE PROJECT_MANAGER_STATUS='APPROVED'";

	
	private static final String UPDATE_sample="UPDATE travelling_request_details SET TRAVEL_DETAILS_ID =(select max(TRAVEL_DETAILS_ID) from travelling_details)  WHERE TRAVEL_REQUEST_ID = ?" ;
	@Override
	public boolean addTravellingRequestDetails(TravellingRequestDetails travellingRequestDetails) {
		System.out.println(travellingRequestDetails);
		Object[] args= {travellingRequestDetails.getTravelDepartureDate(),travellingRequestDetails.getTravelReturndate(),travellingRequestDetails.getTravelReason(),travellingRequestDetails.getTravelMode(),travellingRequestDetails.getTarvelStatus(),travellingRequestDetails.getProjectManagerStatus(),travellingRequestDetails.getDirectorstatus(),travellingRequestDetails.getTravelLocation(),travellingRequestDetails.getEmployeeDetails().getEmployeeDetailsId()};
		resultCount=jdbcTemplate.update(INSERT_TravellingRequestDetails,args);
		if(resultCount>0)
			return true;
		else 
			return false;
	}

	@Override
	public TravellingRequestDetails getTravellingRequestDetailsBytravelRequestId(int travelRequestId) {
		Object[] args = { travelRequestId };
		TravellingRequestDetails travellingRequestDetails = jdbcTemplate.queryForObject(SELECT_SINGLE_TravellingRequestDetailsBytravelRequestId, travlingRequestDetailsRowMapper, args);
		return travellingRequestDetails;
	}
	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetails() {
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_TravellingRequestDetails, travlingRequestDetailsRowMapper);
		return travellingRequestDetails ;
	}

	@Override
	public boolean updateTravellingRequestDetailsBytravelRequestId(TravellingRequestDetails travellingRequestDetails) {
		
		Object[] args= {travellingRequestDetails.getTarvelStatus(),travellingRequestDetails.getTravelRequestId()           };
		resultCount=jdbcTemplate.update(UPDATE_travelTravellingRequestDetailsBytravelRequestId,args);
		if(resultCount>0)
			return true;
		else 
			return false;
	}



	@Override
	public boolean updateManagerStatusBytravelRequestId(TravellingRequestDetails travellingRequestDetails) {
		Object[] args= {travellingRequestDetails.getProjectManagerStatus(),travellingRequestDetails.getTravelRequestId()};
		resultCount=jdbcTemplate.update(UPDATE_Manager_Status,args);
		if(resultCount>0)
			return true;
		else 
			return false;
	}



	@Override
	public boolean updateDirectorStatusBytravelRequestId(TravellingRequestDetails travellingRequestDetails) {
		Object[] args= {travellingRequestDetails.getDirectorstatus(),travellingRequestDetails.getTravelRequestId()};
		resultCount=jdbcTemplate.update(UPDATE_Director_Status,args);
		if(resultCount>0)
			return true;
		else 
			return false;
	}



	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetailsByEmployeeId(int employeeId) {
		Object[] args= {employeeId};
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_TravellingReqestsByEMPId, travlingRequestDetailsRowMapper,args);
		
		return travellingRequestDetails ;
	}



	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetailsForaAgent() {
		
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_TRAVELINGREQFORAGENT, travlingRequestDetailsRowMapper);
		return travellingRequestDetails ;
	}



	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestByManagerId(int managerId) {
		Object[] args= {managerId};
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_TRAVELINGREQUESTBYMANAGERID, travlingRequestDetailsRowMapper,args);
		
		return travellingRequestDetails ;
		
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingPendingRequestByManagerId(int managerId) {
		Object[] args= {managerId};
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_PENDING_TRAVELINGREQUEST_BY_MANAGERID, travlingRequestDetailsRowMapper,args);
		
		return travellingRequestDetails ;
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingAcceptRequestByManagerId(int managerId) {
		Object[] args= {managerId};
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_ACCEPT_TRAVELINGREQUEST_BY_MANAGERID, travlingRequestDetailsRowMapper,args);
		
		return travellingRequestDetails ;
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingRejectedRequestByManagerId(int managerId) {
		Object[] args= {managerId};
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_REJECT_TRAVELINGREQUEST_BY_MANAGERID, travlingRequestDetailsRowMapper,args);
		
		return travellingRequestDetails ;
			}

	
	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetailsForDirector() {
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_TRVALING_REQUEST_FOR_DIRECTOR, travlingRequestDetailsRowMapper);
		return travellingRequestDetails ;
	}

	@Override
	public List<TravellingRequestDetails> getAllAcceptedTravellingRequestDetailsForAgent() {
		
		List<TravellingRequestDetails> travellingRequestDetails = jdbcTemplate.query(SELECT_ALL_ACCEPTED_TRVALING_REQUEST_FOR_AGENT, travlingRequestDetailsRowMapper);
		return travellingRequestDetails ;
	}

	@Override
	public boolean updateTravellingRequestDetailsByAllEmployee(TravellingRequestDetails travellingRequestDetails) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertTravalDetails(TravellingRequestDetails travellingRequestDetails) {
		Object[] args= {travellingRequestDetails.getTravelRequestId()};
		resultCount=jdbcTemplate.update(UPDATE_sample,args);
		if(resultCount>0)
			return true;
		else 
			return false;
	}
	
	               
	
	
//	@Override
//	public boolean updateTravellingRequestDetailsBytravelRequestId(TravellingRequestDetails travellingRequestDetails) {
//		Object[] args= {travellingRequestDetails.getTravelDepartureDate(),travellingRequestDetails.getTravelReturndate(),travellingRequestDetails.getTravelReason(),travellingRequestDetails.getTravelMode(),travellingRequestDetails.getTarvelStatus(),travellingRequestDetails.getProjectManagerStatus(),travellingRequestDetails.getDirectorstatus(),travellingRequestDetails.getEmployeeDetails().getEmployeeDetailsId(),travellingRequestDetails.getTravelLocation(),travellingRequestDetails.getTravelDetails().getTravelDetailsId(),travellingRequestDetails.getTravelDocumentDetails().getDocumentId(),travellingRequestDetails.getTravelRequestId()};
//		resultCount=jdbcTemplate.update(UPDATE_travelTravellingRequestDetailsBytravelRequestId,args);
//		if(resultCount>0)
//			return true;
//		else 
//			return false;
//	}
//
//	@Override
//	public boolean deleteTravellingRequestDetailsBytravelRequestId(int travelRequestId) {
//		Object[] args = {travelRequestId};
//		resultCount = jdbcTemplate.update(DELETE_TravellingRequestDetailsBytravelRequestId, args);
//		if (resultCount > 0)
//			return true;
//		else
//			return false;
//	}

}
